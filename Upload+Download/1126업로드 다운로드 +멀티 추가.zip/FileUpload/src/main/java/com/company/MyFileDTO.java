package com.company;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class MyFileDTO {
	
	private String idx;
	private String title;
	private String cate;
	private String ofile;
	private String sfile;
	private String postdate;

}
