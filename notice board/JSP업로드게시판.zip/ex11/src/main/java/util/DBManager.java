package util;

import java.sql.Statement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

public class DBManager {

    // 데이터베이스 연결을 가져오는 메소드
    public static Connection getConnection() {
        Connection conn = null;
        try {
            // JNDI를 통해 데이터소스를 조회하여 연결을 얻음
            Context initContext = new InitialContext();
            Context envContext = (Context) initContext.lookup("java:/comp/env");
            DataSource ds = (DataSource) envContext.lookup("jdbc/oracle");
            conn = ds.getConnection();
        } catch (NamingException e) {
            System.err.println("JNDI lookup failed: " + e.getMessage());
            e.printStackTrace();
        } catch (SQLException e) {
            System.err.println("Database connection failed: " + e.getMessage());
            e.printStackTrace();
        }
        return conn;
    }

    // ResultSet, Statement, Connection을 닫는 메소드
    public static void close(Connection conn, Statement stmt, ResultSet rs) {
        try {
            if (rs != null) {
                rs.close();
            }
            if (stmt != null) {
                stmt.close();
            }
            if (conn != null) {
                conn.close();
            }
        } catch (SQLException e) {
            System.err.println("Error while closing resources: " + e.getMessage());
            e.printStackTrace();
        }
    }

    // Statement, Connection을 닫는 메소드 (DML 작업 후)
    public static void close(Connection conn, Statement stmt) {
        try {
            if (stmt != null) {
                stmt.close();
            }
            if (conn != null) {
                conn.close();
            }
        } catch (SQLException e) {
            System.err.println("Error while closing resources: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
