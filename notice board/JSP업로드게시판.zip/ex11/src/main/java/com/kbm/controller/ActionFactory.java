package com.kbm.controller;

import com.kbm.controller.action.Action;
import com.kbm.controller.action.BoardCheckPassAction;
import com.kbm.controller.action.BoardCheckPassFormAction;
import com.kbm.controller.action.BoardDeleteAction;
import com.kbm.controller.action.BoardListAction;
import com.kbm.controller.action.BoardUpdateAction;
import com.kbm.controller.action.BoardUpdateFormAction;
import com.kbm.controller.action.BoardViewAction;
import com.kbm.controller.action.BoardWriteAction;
import com.kbm.controller.action.BoardWriteFormAction;

public class ActionFactory {
	private static ActionFactory instance = new ActionFactory();

	private ActionFactory() {
		super();
	}

	public static ActionFactory getInstance() {
		return instance;
	}

	public Action getAction(String command) {
		Action action = null;
		System.out.println("ActionFactory :" + command);
		if (command.equals("board_list")) {
			action = new BoardListAction();
		
		} else if (command.equals("board_write_form")) {
			action = new BoardWriteFormAction();
	
		} else if (command.equals("board_write")) {
			action = new BoardWriteAction();

		} else if (command.equals("board_view")) {
			action = new BoardViewAction();
			
		} else if (command.equals("board_check_pass_form")) {
			action = new BoardCheckPassFormAction();	
		
		} else if (command.equals("board_check_pass")) {
			action = new BoardCheckPassAction();
		
		} else if (command.equals("board_update_form")) {
			action = new BoardUpdateFormAction();
		
		}  else if (command.equals("board_update")) {
				action = new BoardUpdateAction();
			
		} else if (command.equals("board_delete")) {
				action = new BoardDeleteAction();
			}
		
		return action;
	}
}

/*BoardServlet.java  
(서블릿파일)

요청을 받아서 해당하는 
Model과 View를 
호출하는 역할 29쪽 11장 게시판 전체코드이어서 작업할것 */