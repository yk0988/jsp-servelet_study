package com.kbm.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.kbm.controller.action.Action;
/*BoardServlet 클래스의 doGet() 
 메서드에서 ActionFactory 객체를 생성한 후 BoardServlet을 요청하면서 전달된 
command 요청 파라미터 값을 ActionFactory 객체의 getActiom()메서에 전달해 준다. 
getAction()메소드가 리턴해 준 action 객체로 execute() 메서드를 호출한다.*/

@WebServlet("/BoardServlet")
public class BoardServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String command = request.getParameter("command");
		System.out.println("BoardServlet에서 요청 받음 : " + command);
		System.out.println("BoardServlet에서 요청을 받음을 확인 : " + command);
		ActionFactory af=ActionFactory.getInstance();
				
		Action action = af.getAction(command);

		if(action != null){
		  action.execute(request, response);   //execute메소드 아직 구현안했음
		}
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		doGet(request, response);
		
	}

}
